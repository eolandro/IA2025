def dlabel(label):
    if label[-1] != ":":
        return False
    lb = label[:-1]
    if lb.isdigit():
        return True
    elif lb.isalnum() and lb.isupper():
        return True
    return False

def opera_senact(SensorAct,Dir):
    R1 = SensorAct in ["mov","obs"]
    R2 = Dir in ["r","l","u","d"]
    return R1 and R2

def linea_codigo(linea):
    if not linea:
        return False
    lsep = linea.split(" ")
    match lsep:
        case [label]: #1
            return dlabel(label)
        case [SensorAct,Dir]: #2
            return opera_senact(SensorAct,Dir)
        case [Ins,Z1,Z2,Z3]: #4
            if Ins[0]=="j": #Salto
                pass
            else: #Operación Matemática
                pass
    return False