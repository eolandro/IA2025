# Analisis.py

def dlabel(label):
    if label[-1] != ":":
        return False
    lb = label[:-1]
    return lb.isdigit() or (lb.isalnum() and lb.isupper())

def opera_senact(SensorAct, Dir):
    return SensorAct in ["mov", "obsv"] and Dir in ["r", "l", "u", "d"]

def linea_codigo(linea):
    if not linea:
        return False
    lsep = linea.split()
    match lsep:
        case [label]:  # Etiqueta
            return dlabel(label)
        case [SensorAct, Dir]:  # Movimiento u observación
            return opera_senact(SensorAct, Dir)
        case [Ins, Z1, Z2, Z3]:  # Instrucciones con 3 operandos
            if Ins.startswith("j"):  # Salto
                return Z1.isdigit() or dlabel(Z1)
            else:  # Operación matemática
                return all(z in ["AX", "BX", "CX", "DX"] or z.isdigit() for z in [Z1, Z2, Z3])
    return False