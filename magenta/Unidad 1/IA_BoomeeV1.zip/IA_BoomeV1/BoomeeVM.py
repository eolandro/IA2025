class BoomeVM:
    def __init__(self):  # Constructor
        self.Registros = {"AX": 0, "BX": 0, "CX": 0, "DX": 0}
        self.Mapa = [
            [3, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0],
            [1, 0, 1, 0, 1, 0, 1, 0],
            [1, 0, 1, 0, 1, 0, 1, 0],
            [0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 2, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0],
        ]
        self.fila, self.columna = 0, 0
        self.lineaEjecutando = ""
        self.Vivo = True

    def __str__(self):
        tmp = f"Registros: {self.Registros} \n"
        tmp += f"Línea Ejecutando: {self.lineaEjecutando} \n"
        tmp += f"Vivo: {self.Vivo} \n"
        #tmp += f"Pos: {self.fila+1}, {self.columna+1} \n"
        tmp += f"Pos: {self.fila}, {self.columna} \n"
        for l in self.Mapa:
            tmp += str(l) + "\n"
        return tmp

    def ejecutar_linea(self, linea):
        sentencia = linea.split()
        match sentencia:
            case [label]:  # 1
                pass
            case ["mov", "r"]:  # 2
                # Implementar actuador
                self.columna = self.columna + 1
                if self.columna >= len(self.Mapa[self.fila]):
                    self.Vivo = False
                if self.Vivo:
                    self.Mapa[self.fila][self.columna - 1] = 0
                    self.Mapa[self.fila][self.columna] = 3
            case ["mov", "l"]:  # 2
                # Implementar sensor
                self.columna = self.columna - 1
                if self.columna <= 0:
                    self.Vivo = False
                if self.Vivo:
                    self.Mapa[self.fila][self.columna + 1] = 0
                    self.Mapa[self.fila][self.columna] = 3
            case ["obsv", Dir]:  # 2
                pass
            case [Ins, Z1, Z2, Z3]:  # 4
                if Ins[0] == "j":  # Salto
                    pass
                else:  # Operación Matemática
                    pass