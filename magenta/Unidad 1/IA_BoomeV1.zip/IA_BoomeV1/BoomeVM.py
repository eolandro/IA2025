# BoomeVM.py

class BoomeVM:
    def __init__(self):
        self.Registros = {"AX": 0, "BX": 0, "CX": 0, "DX": 0}
        self.Mapa = [
            [3, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0],
            [1, 0, 1, 0, 1, 0, 1, 0],
            [1, 0, 1, 0, 1, 0, 1, 0],
            [0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 2, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0],
        ]
        self.fila, self.columna = 0, 0
        self.lineaEjecutando = ""
        self.Vivo = True

    def __str__(self):
        tmp = f"Registros: {self.Registros}\n"
        tmp += f"Línea Ejecutando: {self.lineaEjecutando}\n"
        tmp += f"Vivo: {self.Vivo}\n"
        tmp += f"Pos: {self.fila}, {self.columna}\n"
        tmp += "\n".join(str(l) for l in self.Mapa)
        return tmp

    def ejecutar_linea(self, linea):
        sentencia = linea.split()
        match sentencia:
            case [label]:  # Etiqueta
                pass
            case ["mov", dir]:  # Movimiento
                delta = {"r": (0, 1), "l": (0, -1), "u": (-1, 0), "d": (1, 0)}.get(dir, (0, 0))
                nueva_fila = self.fila + delta[0]
                nueva_columna = self.columna + delta[1]
                if 0 <= nueva_fila < len(self.Mapa) and 0 <= nueva_columna < len(self.Mapa[0]):
                    self.Mapa[self.fila][self.columna] = 0
                    self.fila, self.columna = nueva_fila, nueva_columna
                    self.Mapa[self.fila][self.columna] = 3
                else:
                    self.Vivo = False
            case ["obsv", dir]:  # Observación
                delta = {"r": (0, 1), "l": (0, -1), "u": (-1, 0), "d": (1, 0)}.get(dir, (0, 0))
                obs_fila, obs_columna = self.fila + delta[0], self.columna + delta[1]
                if 0 <= obs_fila < len(self.Mapa) and 0 <= obs_columna < len(self.Mapa[0]):
                    print(f"Observando en {dir}: {self.Mapa[obs_fila][obs_columna]}")
                else:
                    print("Observación fuera de límites")