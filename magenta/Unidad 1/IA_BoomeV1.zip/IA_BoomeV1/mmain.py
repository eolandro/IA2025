from analizarls import linea_codigo
from BoomeeVM import BoomeVM
from pathlib import Path

import argparse

parser = argparse.ArgumentParser(
    prog='BoomeVM',
    description='Ejecuta instrucciones almacenadas en un archivo',
    epilog='Creado para no morir en el semestre'
)

parser.add_argument('archivo_codigo')

def main(archivo_codigo):
    with archivo_codigo.open() as codigo:
        Boome = BoomeVM()
        print(Boome)
        for linea in codigo:
            if not Boome.Vivo:
                break
            linea = linea.strip()
            print("#: " ,linea)
            R = linea_codigo(linea)
            print(R)
            if R:
                Boome.ejecutar_linea(linea)
                print(Boome)
            input("Presiona ENTER para continuar...")

if __name__ == "__main__":
    args = parser.parse_args()
    ruta = Path(args.archivo_codigo)
    if ruta.exists():
        main(ruta)
    else:
        print("No se encontró el archivo especificado",args.archivo_codigo)