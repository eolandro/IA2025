# main.py

from analizarls import linea_codigo
from BoomeVM import BoomeVM
from pathlib import Path
import argparse

def main(archivo_codigo):
    with archivo_codigo.open() as codigo:
        Boome = BoomeVM()
        print(Boome)
        for linea in codigo:
            if not Boome.Vivo:
                print("El personaje ha muerto. Fin de la ejecución.")
                break
            linea = linea.strip()
            if not linea:
                continue
            print(f"Ejecutando: {linea}")
            if linea_codigo(linea):
                Boome.ejecutar_linea(linea)
                print(Boome)
            else:
                print(f"Línea inválida: {linea}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Ejecuta instrucciones de BoomeVM')
    parser.add_argument('archivo_codigo', type=Path, help='Ruta del archivo con instrucciones')
    args = parser.parse_args()
    if args.archivo_codigo.exists():
        main(args.archivo_codigo)
    else:
        print(f"No se encontró el archivo: {args.archivo_codigo}")