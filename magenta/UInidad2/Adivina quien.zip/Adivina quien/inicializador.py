from ruamel.yaml import YAML

def recolectar_datos():
    datos = {"animales": [], "caracteristicas": []}
    print("\nBienvenido Iniciemos\n")
    for i in range(10):  
        animal = input("Dame el nombre del animal (o da enter para terminar) " + str(i+1) + ": ").strip()
        if not animal:  
            break
        datos["animales"].append(animal)
    
    while True:
        caracteristica = input("Ingresa una característica (o da enter para terminar): ").strip()
        if not caracteristica:
            break
        datos["caracteristicas"].append(caracteristica)
    
    yaml = YAML()
    with open("preguntas_animales.yaml", "w") as archivo:
        yaml.dump(datos, archivo)
    
    print("Datos guardados en preguntas_animales.yaml")

if __name__ == "__main__":
    recolectar_datos()
