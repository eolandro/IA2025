from ruamel.yaml import YAML

def cargar_tabla():
    yaml = YAML()
    with open("tabla.yaml", "r") as archivo:
        return yaml.load(archivo)

def hacer_preguntas(tabla):
    animales = list(tabla.keys())
    preguntas = list(next(iter(tabla.values())).keys()) 
    
    print("\nAnimales existentes a adivinar:")
    for animal in animales:
        print("*", animal) 
    print("\n¡Vamos a adivinar tu animal!\n")

    respuestas = {}
    for pregunta in preguntas:
        respuesta = input("¿El animal tiene la característica '" + pregunta + "'? (S/N): ").strip().lower()
        if respuesta == 's':
            respuestas[pregunta] = 1
        elif respuesta == 'n':
            respuestas[pregunta] = 0

    puntajes = {animal: sum(1 for carac, valor in respuestas.items() if tabla[animal].get(carac) == valor)
                for animal in animales}

    puntajes_ordenados = sorted(puntajes.items(), key=lambda item: item[1], reverse=True)

    mejor_puntaje = puntajes_ordenados[0][1]

    animales_probables = [animal for animal, puntaje in puntajes_ordenados if puntaje == mejor_puntaje]

    if len(animales_probables) == 1:
        print("\nEl animal que pensaste es: " + animales_probables[0] + "\n")
    else:
        print("\nVaya! Hubo un empate los animales en comun son:")
        for animal in animales_probables:
            print("- " + animal)
        print("\n")
        

def main():
    tabla = cargar_tabla()  
    hacer_preguntas(tabla)

if __name__ == "__main__":
    main()

